<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_m extends CI_Model {
	public function get ($id = null)
	{

		$this->db->from('biodata');
		if($id != null) {
			$this->db->where('id_mhs', $id);
		}
		$query = $this->db->get();
		return $query;

	}
	public function add($post)
	{
		$params = [
			'nama_mhs'					=>		$post['nama_mhs'],
			'tgl_lhr'				=>		$post['tgl_lhr'],
			'no_hp'				=>		$post['no_hp'],
			'jurusan'				=>		$post['jurusan'],
			'nim_mhs'		=>		$post['nim_mhs'],
		];
		$this->db->insert('biodata', $params);
	}
	public function edit($post)
	{
		$params = [
			'nama_mhs'					=>		$post['nama_mhs'],
			'tgl_lhr'				=>		$post['tgl_lhr'],
			'no_hp'				=>		$post['no_hp'],
			'jurusan'				=>		$post['jurusan'],
			'nim_mhs'		=>		$post['nim_mhs'],
		];
		$this->db->where('id_mhs', $post['id_mhs']);
		$this->db->update('biodata', $params);
	}
	public function del($id)
	{
		$this->db->where('id_mhs', $id);
		$this->db->delete('biodata');
	}
}