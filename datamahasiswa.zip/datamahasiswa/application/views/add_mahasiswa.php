<!-- Main Content -->
<div class="container-fluid">
  <section class="content">

    <div class="card">
      <div class="card-header with-border">
      <div class="card-header py-3 ">
        <h6 class="m-0 font-weight-bold text-primary  "><?= ucfirst($page) ?> Data Mahasiswa</h6>
         
    </div>
        


      <div class="card-body">
        <div class="row">
          <div class="col-md-12 col-md-offset-4">

            <form action="<?= site_url('chome/process') ?>" method="post">
              
              <div class="form-group">
                <label>NIM Mahasiswa *</label>
                <input type="number" name="nim_mhs" value="<?= $row->nim_mhs ?>" class="form-control" required>
              </div>

              <div class="form-group">
                <label>Nama Mahasiswa *</label>
                <input type="hidden" name="id_mhs" value="<?= $row->id_mhs ?>">
                <input type="text" name="nama_mhs" value="<?= $row->nama_mhs ?>" class="form-control" required>
              </div>

              <div class="form-group">
                <label>Tanggal Lahir *</label>
                <input type="date" name="tgl_lhr" value="<?= $row->tgl_lhr ?>" class="form-control" required>
              </div>

              <div class="form-group">
                <label>Nomor HP *</label>
                <input type="number" name="no_hp" value="<?= $row->no_hp ?>" class="form-control" required>
              </div>

              <div class="form-group">
                <label>Jurusan *</label>
                <select name="jurusan" class="form-control" required>
                  <option value="<?= $row->jurusan ?>"><?= $row->jurusan ?></option>
                  <option value="Teknik Informatika">Teknik Informatika</option>
                  <option value="Teknik Industri">Teknik Industri</option>
                </select>
              </div>

              <div class="form-group">
                <button type="submit" name="<?= $page ?>" class="btn btn-success btn-flat">
                  <i class="fa fa-paper-plane"></i> Save
                </button>
                <button type="reset" class="btn btn-default btn-flat">Reset</button>
                <a href="<?= site_url('Chome') ?>" class="btn btn-warning btn-flat">
            <i class="fa fa-undo"></i> Back
          </a>
              </div>

            </form>

          </div>
        </div>
      </div>
    </div>

  </section>
</div>
