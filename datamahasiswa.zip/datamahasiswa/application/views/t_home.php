<!-- Begin Page Content -->
<div class="container-fluid">   
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3 ">
        <h6 class="m-0 font-weight-bold text-primary ">Daftar Data Mahasiswa</h6>
    </div>
    <div class="card-body">
        <div class="card-header">
        <a href="<?= site_url('chome/add')?>" class="btn btn-success btn-xs">
            <i class="fa fa-plus"></i> Tambah
        </a>

        </div>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIM</th>
                        <th>Nama Mahasiswa</th>
                        <th>Tanggal Lahir</th>
                        <th>No HP</th>
                        <th>Jurusan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $no = 1 ; 
					foreach($row->result() as $key => $data) { ?>
                    <tr>
                        <td><?=$no++ ?>.</td>
                        <td><?=$data->nim_mhs?></td>
                        <td><?=$data->nama_mhs?></td>
                        <td><?=$data->tgl_lhr?></td>
                        <td><?=$data->no_hp?></td>
                        <td><?=$data->jurusan?></td>
                        <td>
                        <a href="<?= site_url ('Chome/edit/'.$data->id_mhs) ?>" class="btn btn-primary btn-xs">
                        <i class="fa fa-pencil-alt"></i> 
                        </a>

                        <a href="<?= site_url ('Chome/del/'.$data->id_mhs) ?>#" class="btn btn-danger btn-xs">
                        <i class="fa fa-trash"></i> 
                        </a>

                        <a id="set" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#modal-viewmahasiswa" 
			      				data-nim_mhs="<?=$data->nim_mhs?>"
			      				data-nama_mhs="<?=$data->nama_mhs?>"
			      				data-tgl_lhr="<?=$data->tgl_lhr?>"
			      				data-jurusan="<?=$data->jurusan?>"
			      				>
			          <i class="fa fa-eye"></i> 

                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<div class="modal fade" id="modal-viewmahasiswa" tabindex="-1" role="dialog" aria-labelledby="modalMahasiswaLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content" style="border-radius: 10px;">
      
      <div class="modal-header bg-primary text-white" style="border-top-left-radius: 10px; border-top-right-radius: 10px;">
       
        <h4 class="modal-title">
          <i class="fa fa-user-graduate"></i> Detail Data Mahasiswa
        </h4>
      </div>

      <div class="modal-body table-responsive">
        <table class="table table-hover">
          <tbody>
            <tr>
              <th><i class="fa fa-id-card"></i> NIM Mahasiswa</th>
              <td><span id="nim_mhs"></span></td>
            </tr>
            <tr>
              <th><i class="fa fa-user"></i> Nama Mahasiswa</th>
              <td><span id="nama_mhs"></span></td>
            </tr>
            <tr>
              <th><i class="fa fa-calendar"></i> Tanggal Lahir</th>
              <td><span id="tgl_lhr"></span></td>
            </tr>
            <tr>
              <th><i class="fa fa-graduation-cap"></i> Jurusan</th>
              <td><span id="jurusan"></span></td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">
          <i class="fa fa-times"></i> Tutup
        </button>
      </div>

    </div>
  </div>
</div>

<!-- /.container-fluid -->
