<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('Home_m');
	}

	

	public function index()
	{
		$data['row']	=	$this->Home_m->get();
		$this->template->load('template', 't_home',$data);	
	}
		
		public function add()
	{
		$biodata  =  new stdClass();
		$biodata->id_mhs = null;
		$biodata->nama_mhs = null;
		$biodata->tgl_lhr = null;
		$biodata->no_hp = null;
		$biodata->jurusan = null;
		$biodata->nim_mhs = null;
		$data  =  array(
			'page'	=>	'add',
			'row'	=>	$biodata
		);
		$this->template->load('template', 'add_mahasiswa', $data);
	}
	public function edit($id)
	{
		$query = $this->Home_m->get($id);
		if ($query->num_rows() > 0) {
			$biodata = $query->row();
			$data  =  array(
			'page'	=>	'edit',
			'row'	=>	$biodata
		);
			$this->template->load('template', 'add_mahasiswa', $data);
		}else{
			echo "<script>alert('Data tidak ditemukan');</script>";
			echo "<script>window.location='".site_url('chome')."';</script>";
		}
	}
	public function process()
	{
		$post = $this->input->post(null, TRUE);
		if (isset($_POST['add'])) {
			$this->Home_m->add($post);
		} else if (isset($_POST['edit'])) {
			$this->Home_m->edit($post);
		}

		if ($this->db->affected_rows() > 0) {
				echo "<script>alert('Berhasil!');</script>";}
				echo "<script>window.location='".site_url('Chome')."';</script>";
	}
	public function del($id)
	{
		$this->Home_m->del($id);
		if ($this->db->affected_rows() > 0) {
				echo "<script>alert('Data Mahasiswa berhasil dihapus!');</script>";
			}
			echo "<script>window.location='".site_url('chome')."';</script>";
	}
}

